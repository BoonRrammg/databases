CREATE TABLE luggage (
    luggage_id SERIAL PRIMARY KEY,
    status luggage_status NOT NULL,
    description VARCHAR(100),
    specialness BOOLEAN NOT NULL,
    ticket_id INTEGER NOT NULL REFERENCES ticket(ticket_id)
);