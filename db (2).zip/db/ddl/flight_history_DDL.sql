CREATE TABLE flight_history (
    history_id SERIAL PRIMARY KEY,
    flight_id INTEGER NOT NULL REFERENCES flight(flight_id),
    status flight_status,
    change_time TIMESTAMP NOT NULL,
    reason VARCHAR(300)
);