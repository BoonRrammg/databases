CREATE TABLE flight (
    flight_id SERIAL PRIMARY KEY,
    status flight_status,
    departure_time TIMESTAMP,
    arrival_time TIMESTAMP,
    gate VARCHAR(10),
    plane_id INTEGER NOT NULL REFERENCES plane(plane_id),
    destination_id INTEGER NOT NULL REFERENCES destination(destination_id),
    type flight_type,
    flight_number VARCHAR(20) NOT NULL,
    direction flight_direction NOT NULL
);