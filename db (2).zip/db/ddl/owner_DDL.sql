CREATE TABLE owner (
    owner_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    type owner_type NOT NULL
);