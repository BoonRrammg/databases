CREATE TABLE plane (
    plane_id SERIAL PRIMARY KEY,
    number VARCHAR(50),
    model VARCHAR(50) NOT NULL,
    operator_id INTEGER NOT NULL REFERENCES operator(operator_id),
    owner_id INTEGER NOT NULL REFERENCES owner(owner_id)
);