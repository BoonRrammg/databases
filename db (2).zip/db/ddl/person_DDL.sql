CREATE TABLE person (
    person_id SERIAL PRIMARY KEY,
    role person_role NOT NULL,
    name VARCHAR(50) NOT NULL,
    surname VARCHAR(50) NOT NULL,
    passport_number VARCHAR(50),
    info VARCHAR(200)
);