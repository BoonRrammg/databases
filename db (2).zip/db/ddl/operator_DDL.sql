CREATE TABLE operator (
    operator_id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    type operator_type NOT NULL
);