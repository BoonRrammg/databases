CREATE TABLE ticket (
    ticket_id SERIAL PRIMARY KEY,
    status ticket_status,
    person_id INTEGER NOT NULL REFERENCES person(person_id),
    type ticket_type NOT NULL,
    flight_id INTEGER NOT NULL REFERENCES flight(flight_id)
);